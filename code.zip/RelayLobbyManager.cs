using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Unity.Netcode;
using Unity.Netcode.Transports.UTP;
using Unity.Networking.Transport.Relay;
using Unity.Services.Authentication;
using Unity.Services.Core;
using Unity.Services.Lobbies;
using Unity.Services.Lobbies.Models;
using Unity.Services.Relay;
using Unity.Services.Relay.Models;
using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class RelayLobbyManager : MonoBehaviour
{
    [Header("UI References")]
    [SerializeField] private Button createLobbyButton;
    [SerializeField] private Button joinLobbyButton;
    [SerializeField] private TMP_InputField lobbyCodeInput;
    [SerializeField] private TMP_InputField lobbyNameInput;
    [SerializeField] private TextMeshProUGUI statusText;
    [SerializeField] private TextMeshProUGUI lobbyInfoText;
    [SerializeField] private TextMeshProUGUI lobbyCodeDisplayText;

    [Header("Lobby Settings")]
    [SerializeField] private int maxPlayers = 4;
    [SerializeField] private bool isPrivate = false;

    private Lobby currentLobby;
    private UnityTransport transport;
    private const float HEARTBEAT_TIMER = 15f;
    private const float LOBBY_UPDATE_TIMER = 1.1f;
    private float heartbeatTimer;
    private float lobbyUpdateTimer;

    private async void Start()
    {
        transport = FindFirstObjectByType<UnityTransport>();
        await InitializeUnityServices();
        SetupUI();
    }

    private async Task InitializeUnityServices()
    {
        try
        {
            UpdateStatus("Initializing Unity Services...");
            Debug.Log("[RelayLobbyManager] UnityServices State: " + UnityServices.State);

            if (UnityServices.State != ServicesInitializationState.Initialized)
                await UnityServices.InitializeAsync();

            if (!AuthenticationService.Instance.IsSignedIn)
            {
                await AuthenticationService.Instance.SignInAnonymouslyAsync();
                Debug.Log("[RelayLobbyManager] PlayerId after sign-in: " + AuthenticationService.Instance.PlayerId);
                UpdateStatus($"Signed in: {AuthenticationService.Instance.PlayerId}");
            }
        }
        catch (Exception e)
        {
            UpdateStatus($"Initialization failed: {e.Message}");
            Debug.LogError($"[RelayLobbyManager] Unity Services initialization failed: {e}");
        }
    }

    private void SetupUI()
    {
        if (createLobbyButton != null)
            createLobbyButton.onClick.AddListener(() => CreateLobby());

        if (joinLobbyButton != null)
            joinLobbyButton.onClick.AddListener(() => JoinLobbyByCode());

        if (lobbyNameInput != null)
            lobbyNameInput.text = $"Lobby_{UnityEngine.Random.Range(1000, 9999)}";
    }

    private async void CreateLobby()
    {
        try
        {
            UpdateStatus("Creating lobby...");

            Allocation allocation = await RelayService.Instance.CreateAllocationAsync(maxPlayers - 1);
            string relayJoinCode = await RelayService.Instance.GetJoinCodeAsync(allocation.AllocationId);
            Debug.Log("[RelayLobbyManager] Allocation created. RelayJoinCode: " + relayJoinCode);

            CreateLobbyOptions options = new CreateLobbyOptions
            {
                IsPrivate = isPrivate,
                Data = new Dictionary<string, DataObject>
                {
                    { "START_GAME", new DataObject(DataObject.VisibilityOptions.Member, "0") },
                    { "RELAY_JOIN_CODE", new DataObject(DataObject.VisibilityOptions.Member, relayJoinCode) }
                }
            };

            string lobbyName = string.IsNullOrEmpty(lobbyNameInput?.text) ?
                               $"Lobby_{UnityEngine.Random.Range(1000, 9999)}" :
                               lobbyNameInput.text;

            currentLobby = await LobbyService.Instance.CreateLobbyAsync(lobbyName, maxPlayers, options);
            Debug.Log("[RelayLobbyManager] Lobby created. ID: " + currentLobby.Id);

            transport.SetRelayServerData(allocation.RelayServer.IpV4, (ushort)allocation.RelayServer.Port,
                allocation.AllocationIdBytes, allocation.Key, allocation.ConnectionData);

            NetworkManager.Singleton.StartHost();

            UpdateStatus("Lobby created successfully!");
            UpdateLobbyInfo($"Lobby Code: {currentLobby.LobbyCode}\nPlayers: {currentLobby.Players.Count}/{currentLobby.MaxPlayers}");
            UpdateLobbyCodeDisplay();
        }
        catch (Exception e)
        {
            UpdateStatus($"Failed to create lobby: {e.Message}");
            Debug.LogError($"[RelayLobbyManager] Lobby creation failed: {e}");
        }
    }

    private async void JoinLobbyByCode()
    {
        try
        {
            string lobbyCode = lobbyCodeInput?.text?.Trim();
            if (string.IsNullOrEmpty(lobbyCode))
            {
                UpdateStatus("Please enter a lobby code.");
                return;
            }

            UpdateStatus("Joining lobby...");

            currentLobby = await LobbyService.Instance.JoinLobbyByCodeAsync(lobbyCode);
            Debug.Log("[RelayLobbyManager] JoinLobbyByCodeAsync returned lobby: " + currentLobby?.Name);

            string relayJoinCode = currentLobby.Data["RELAY_JOIN_CODE"].Value;
            Debug.Log("[RelayLobbyManager] Received RelayJoinCode: " + relayJoinCode);

            JoinAllocation allocation = await RelayService.Instance.JoinAllocationAsync(relayJoinCode);

            transport.SetRelayServerData(allocation.RelayServer.IpV4, (ushort)allocation.RelayServer.Port,
                allocation.AllocationIdBytes, allocation.Key, allocation.ConnectionData, allocation.HostConnectionData);

            NetworkManager.Singleton.StartClient();

            UpdateStatus("Joined lobby successfully!");
            UpdateLobbyInfo($"Lobby: {currentLobby.Name}\nPlayers: {currentLobby.Players.Count}/{currentLobby.MaxPlayers}");
            UpdateLobbyCodeDisplay();
        }
        catch (Exception e)
        {
            UpdateStatus($"Failed to join lobby: {e.Message}");
            Debug.LogError($"[RelayLobbyManager] Lobby join failed: {e}");
        }
    }

    private void Update()
    {
        HandleLobbyHeartbeat();
        HandleLobbyPollForUpdates();
    }

    private async void HandleLobbyHeartbeat()
    {
        if (currentLobby != null && IsLobbyHost())
        {
            heartbeatTimer -= Time.deltaTime;
            if (heartbeatTimer < 0f)
            {
                heartbeatTimer = HEARTBEAT_TIMER;
                try
                {
                    Debug.Log("[RelayLobbyManager] Sending heartbeat...");
                    await LobbyService.Instance.SendHeartbeatPingAsync(currentLobby.Id);
                }
                catch (Exception e)
                {
                    Debug.LogError("[RelayLobbyManager] Heartbeat failed: " + e);
                }
            }
        }
    }

    private async void HandleLobbyPollForUpdates()
    {
        if (currentLobby != null)
        {
            lobbyUpdateTimer -= Time.deltaTime;
            if (lobbyUpdateTimer < 0f)
            {
                lobbyUpdateTimer = LOBBY_UPDATE_TIMER;
                try
                {
                    currentLobby = await LobbyService.Instance.GetLobbyAsync(currentLobby.Id);
                    Debug.Log("[RelayLobbyManager] Lobby poll response. Player count: " + currentLobby.Players.Count);
                    UpdateLobbyInfo($"Lobby: {currentLobby.Name}\nPlayers: {currentLobby.Players.Count}/{currentLobby.MaxPlayers}");
                }
                catch (Exception e)
                {
                    Debug.LogError("[RelayLobbyManager] Lobby update failed: " + e);
                }
            }
        }
    }

    public async void LeaveLobby()
    {
        try
        {
            if (currentLobby != null)
            {
                await LobbyService.Instance.RemovePlayerAsync(currentLobby.Id, AuthenticationService.Instance.PlayerId);
                currentLobby = null;

                if (NetworkManager.Singleton != null)
                    NetworkManager.Singleton.Shutdown();

                UpdateStatus("Left the lobby.");
                UpdateLobbyInfo("");
                UpdateLobbyCodeDisplay();
            }
        }
        catch (Exception e)
        {
            Debug.LogError("[RelayLobbyManager] Failed to leave lobby: " + e);
        }
    }

    private bool IsLobbyHost()
    {
        return currentLobby != null &&
               currentLobby.HostId == AuthenticationService.Instance.PlayerId;
    }

    private void UpdateStatus(string message)
    {
        if (statusText != null)
            statusText.text = message;

        Debug.Log("[RelayLobbyManager] " + message);
    }

    private void UpdateLobbyInfo(string info)
    {
        if (lobbyInfoText != null)
            lobbyInfoText.text = info;
    }

    private void UpdateLobbyCodeDisplay()
    {
        if (lobbyCodeDisplayText != null && currentLobby != null)
            lobbyCodeDisplayText.text = currentLobby.LobbyCode;
        else if (lobbyCodeDisplayText != null)
            lobbyCodeDisplayText.text = "";
    }

    private void OnDestroy()
    {
        if (currentLobby != null)
            LeaveLobby();
    }

    [ContextMenu("Debug - Create Test Lobby")]
    private void DebugCreateLobby() => CreateLobby();

    [ContextMenu("Debug - Leave Lobby")]
    private void DebugLeaveLobby() => LeaveLobby();
}