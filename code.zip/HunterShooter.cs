using UnityEngine;
using Unity.Netcode;

public class HunterShooter : NetworkBehaviour
{
    [SerializeField] private Camera fpsCamera;
    [SerializeField] private float range = 50f;
    [SerializeField] private int damage = 20;
    [SerializeField] private LayerMask hitMask;

    private PlayerRoleManager roleManager;

    private LineRenderer lineRenderer;

    void Start()
    {
        roleManager = GetComponent<PlayerRoleManager>();

        // LineRenderer 객체 생성
        GameObject lineObj = new GameObject("HunterRayLine");
        lineObj.transform.SetParent(transform); // 플레이어에 붙이기

        lineRenderer = lineObj.AddComponent<LineRenderer>();
        lineRenderer.positionCount = 2;
        lineRenderer.startWidth = 0.03f;
        lineRenderer.endWidth = 0.03f;
        lineRenderer.useWorldSpace = true;

        // Unlit 빨간색 머티리얼 설정
        var mat = new Material(Shader.Find("Unlit/Color"));
        mat.color = Color.red;
        lineRenderer.material = mat;

        // 처음에는 비활성화
        lineRenderer.enabled = false;
    }

    void Update()
    {
        if (!IsOwner || roleManager == null)
            return;

        // 헌터일 경우 레이 보이게
        if (roleManager.role.Value == PlayerRole.Hunter)
        {
            lineRenderer.enabled = true;
            Vector3 origin = fpsCamera.transform.position;
            Vector3 direction = fpsCamera.transform.forward;
            lineRenderer.SetPosition(0, origin);
            lineRenderer.SetPosition(1, origin + direction * range);
        }
        else
        {
            lineRenderer.enabled = false;
        }

        // F 키로 발사
        if (roleManager.role.Value == PlayerRole.Hunter && Input.GetKeyDown(KeyCode.F))
        {
            ShootServerRpc();
        }
    }

    [ServerRpc]
    void ShootServerRpc(ServerRpcParams rpcParams = default)
    {
        Vector3 origin = fpsCamera.transform.position;
        Vector3 direction = fpsCamera.transform.forward;

        if (Physics.Raycast(origin, direction, out RaycastHit hit, range, hitMask))
        {
            Debug.Log($"[Hunter] Hit {hit.collider.gameObject.name}");

            if (hit.collider.CompareTag("Player"))
            {
                var hp = hit.collider.GetComponentInParent<PlayerHPManager>();
                if (hp != null)
                {
                    hp.TakeDamage(damage);
                }
            }
            else
            {
                var selfHP = GetComponent<PlayerHPManager>();
                if (selfHP != null)
                    selfHP.TakeDamage(damage);
            }
        }
    }
}