using UnityEngine;
using Unity.Netcode;
using System.Collections.Generic;

public enum PlayerRole : byte
{
    None,
    Hunter,
    Prop
}

[System.Serializable]
public struct PropAppearanceData
{
    public Mesh mesh;
    public Material material;
    public Vector3 positionOffset;
}

public class PlayerRoleManager : NetworkBehaviour
{
    public NetworkVariable<PlayerRole> role = new NetworkVariable<PlayerRole>(PlayerRole.None);

    [Header("Visual Target")]
    [SerializeField] private MeshFilter visualMeshFilter;
    [SerializeField] private MeshRenderer visualRenderer;

    [Header("Prop Appearance Options")]
    [SerializeField] private List<PropAppearanceData> propAppearanceList = new();

    private void Awake()
    {
        if (visualMeshFilter == null || visualRenderer == null)
        {
            Debug.LogWarning("[RoleManager] Visual targets not assigned.");
        }
    }

    public override void OnNetworkSpawn()
    {
        if (IsOwner)
            Debug.Log($"[RoleManager] Spawned. My Role: {role.Value}");

        role.OnValueChanged += OnRoleChanged;

        // 초기화 시 현재 역할 적용
        if (IsOwner)
            ApplyRoleVisual(role.Value);
    }

    private void OnRoleChanged(PlayerRole previous, PlayerRole current)
    {
        Debug.Log($"[RoleManager] Role changed from {previous} to {current}");

        if (IsOwner)
            ApplyRoleVisual(current);

        // 서버에서 prop일 경우, 클라이언트에게 외형 전환 지시
        if (IsServer && current == PlayerRole.Prop)
        {
            int index = Random.Range(0, propAppearanceList.Count);
            ChangePropVisualClientRpc(index);
        }
    }

    private void ApplyRoleVisual(PlayerRole role)
    {
        Debug.Log($"[RoleManager] ApplyRoleVisual({role})");

        if (role == PlayerRole.Prop)
        {
            int index = Random.Range(0, propAppearanceList.Count);
            ApplyPropVisual(index);
        }
        else if (role == PlayerRole.Hunter)
        {
            // TODO: Hunter 외형 복구 로직 (필요시)
        }
    }

private void ApplyPropVisual(int index)
{
    if (index < 0 || index >= propAppearanceList.Count)
    {
        Debug.LogWarning("[RoleManager] Invalid prop index.");
        return;
    }

    var data = propAppearanceList[index];

    // 기존 사람 모델 끄기
    SkinnedMeshRenderer[] skinnedRenderers = GetComponentsInChildren<SkinnedMeshRenderer>();
    foreach (var smr in skinnedRenderers)
    {
        smr.enabled = false;
    }

    // 프롭 외형 적용
    if (visualMeshFilter != null && data.mesh != null)
    {
        visualMeshFilter.sharedMesh = data.mesh;
    }

    if (visualRenderer != null && data.material != null)
    {
        visualRenderer.material = data.material;
    }

    if (visualMeshFilter != null)
    {
        visualMeshFilter.transform.localPosition = data.positionOffset;
    }
}

    [ClientRpc]
    private void ChangePropVisualClientRpc(int index)
    {
        if (!IsOwner)
        {
            ApplyPropVisual(index);
        }
    }

    public void SetRole(PlayerRole newRole)
    {
        if (IsServer)
        {
            role.Value = newRole;
        }
    }
}