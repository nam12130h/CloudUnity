using UnityEngine;
using Unity.Netcode;

namespace Polyperfect.Universal
{
    public class PlayerMovement : NetworkBehaviour
    {
        public CharacterController controller;
        public float walkSpeed = 12f;
        public float runSpeedMultiplier = 1.5f;
        public float gravity = -9.81f;
        public float jumpHeight = 3f;

        public Transform groundCheck;
        public float groundDistance = 0.4f;
        public LayerMask groundMask;

        public GameObject playerCamera;

        Vector3 velocity;
        bool isGrounded;

        public override void OnNetworkSpawn()
        {
            Debug.Log($"[Netcode] Player spawned. Owner: {IsOwner}, ClientId: {OwnerClientId}");

            // 카메라 설정
            if (playerCamera != null)
                playerCamera.SetActive(IsOwner);

            // 시작 위치 설정
            if (IsOwner)
            {
                float x = Random.Range(-5f, 5f);
                float z = Random.Range(-5f, 5f);
                transform.position = new Vector3(x, 1.1f, z);
            }

            // CharacterController 할당
            if (controller == null)
                controller = GetComponent<CharacterController>();
        }

        void Update()
        {
            if (!IsOwner || controller == null)
                return;

            // 항상 이동 허용 (지면 무시)
            float x = Input.GetAxis("Horizontal");
            float z = Input.GetAxis("Vertical");

            Vector3 move = transform.right * x + transform.forward * z;
            if (move.magnitude > 1f)
                move.Normalize();

            bool isRunning = Input.GetKey(KeyCode.LeftShift) || Input.GetKey(KeyCode.RightShift);
            float currentSpeed = walkSpeed * (isRunning ? runSpeedMultiplier : 1f);
            controller.Move(move * currentSpeed * Time.deltaTime);

            // 점프는 여전히 지면 체크 필요
            if (groundCheck != null)
            {
                isGrounded = Physics.CheckSphere(groundCheck.position, groundDistance, groundMask);
            }
            else
            {
                isGrounded = controller.isGrounded;
            }

            if (isGrounded && velocity.y < 0)
                velocity.y = -2f;

            if (Input.GetButtonDown("Jump") && isGrounded)
                velocity.y = Mathf.Sqrt(jumpHeight * -2f * gravity);

            // 중력 적용
            velocity.y += gravity * Time.deltaTime;
            controller.Move(velocity * Time.deltaTime);
        }
    }
}