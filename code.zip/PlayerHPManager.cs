using UnityEngine;
using Unity.Netcode;
using TMPro;

public class PlayerHPManager : NetworkBehaviour
{
    [Header("HP Settings")]
    [SerializeField] private int maxHP = 100;
    private NetworkVariable<int> currentHP = new NetworkVariable<int>();

    [Header("UI")]
    [SerializeField] private TextMeshProUGUI hpTextUI;

    public override void OnNetworkSpawn()
    {
        if (IsServer)
            currentHP.Value = maxHP;

        // 로컬 플레이어만 UI 갱신
        if (IsOwner && hpTextUI != null)
        {
            hpTextUI.text = $"HP: {currentHP.Value}";
        }

        currentHP.OnValueChanged += OnHPChanged;
    }

    private void OnDestroy()
    {
        currentHP.OnValueChanged -= OnHPChanged;
    }

    void OnHPChanged(int oldValue, int newValue)
    {
        if (IsOwner && hpTextUI != null)
        {
            hpTextUI.text = $"HP: {newValue}";
        }
    }

    public void TakeDamage(int amount)
    {
        if (!IsServer) return;

        currentHP.Value -= amount;
        Debug.Log($"[HP] Player {OwnerClientId} took {amount} damage. HP: {currentHP.Value}");

        if (currentHP.Value <= 0)
        {
            Debug.Log($"[HP] Player {OwnerClientId} eliminated.");
            // TODO: handle death
        }
    }

    public void Heal(int amount)
    {
        if (!IsServer) return;
        currentHP.Value = Mathf.Min(currentHP.Value + amount, maxHP);
    }
}