using UnityEngine;
using Unity.Netcode;
using System.Collections.Generic;
using System.Linq;

public class GameManager : NetworkBehaviour
{
    public static GameManager Instance;

    void Awake()
    {
        Instance = this;
    }

    [ServerRpc(RequireOwnership = false)]
    public void StartGameServerRpc()
    {
        var players = NetworkManager.Singleton.ConnectedClientsList;

        if (players.Count == 0) return;

        // 랜덤 헌터 선택
        int randomIndex = Random.Range(0, players.Count);
        ulong hunterId = players[randomIndex].ClientId;

        foreach (var client in players)
        {
            var playerObj = client.PlayerObject;
            var roleManager = playerObj.GetComponent<PlayerRoleManager>();

            if (roleManager != null)
            {
                var role = client.ClientId == hunterId ? PlayerRole.Hunter : PlayerRole.Prop;
                roleManager.SetRole(role);
            }
        }

        Debug.Log($"[GameManager] Game Started. Hunter = {hunterId}");
    }
}