using UnityEngine;
using UnityEngine.UI;
using Unity.Netcode;

public class StartGameButtonController : MonoBehaviour
{
    [SerializeField] private Button startGameButton;

    void Start()
    {
        startGameButton.gameObject.SetActive(false);

        // 서버가 시작된 후 실행
        NetworkManager.Singleton.OnServerStarted += OnServerStarted;
    }

    void OnServerStarted()
    {
        if (NetworkManager.Singleton.IsHost)
        {
            startGameButton.gameObject.SetActive(true);
            startGameButton.onClick.AddListener(OnStartGameClicked);
        }
    }

    void OnStartGameClicked()
    {
        if (GameManager.Instance != null)
        {
            GameManager.Instance.StartGameServerRpc();
        }
    }
}